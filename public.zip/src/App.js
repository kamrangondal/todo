import './App.css';

export default function App(){
  return(
    <>
    <div className="centered-div">
      <h1>hello kamran</h1>
    </div>
    <div className="centered-div">
      <h1>hello kamran</h1>
    </div>
    </>
  );
}